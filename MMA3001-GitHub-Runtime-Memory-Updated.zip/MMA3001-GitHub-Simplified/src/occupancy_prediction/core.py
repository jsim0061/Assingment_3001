"""Shared data loading, leakage-aware splitting and regression scoring."""
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
FEATURES = ['current_occupancy','previous_15min','previous_30min','hour','minute','day_of_week']
TARGET='next_15min_occupancy'

def load_data(path):
    """Load a cleaned 15-minute CSV with the six standard model features.

    Args:
        path (str or Path): Path to the processed occupancy CSV.
    Returns:
        pandas.DataFrame: Chronologically ordered observations, with UTC target times.
    Raises:
        ValueError: If required columns are missing or insufficient valid rows exist.
    """
    df=pd.read_csv(path)
    required=FEATURES+[TARGET,'collecteddate']
    missing=sorted(set(required)-set(df.columns))
    if missing:raise ValueError(f'Missing required columns: {missing}')
    df['collecteddate']=pd.to_datetime(df['collecteddate'],utc=True,errors='coerce')
    df['target_time']=pd.to_datetime(df['target_time'],utc=True,errors='coerce') if 'target_time' in df else df['collecteddate']+pd.Timedelta(minutes=15)
    df=df.dropna(subset=required+['target_time']).sort_values('collecteddate').reset_index(drop=True)
    if len(df)<20:raise ValueError('At least 20 valid observations are required')
    if 'target_is_measured' in df:
        df['target_is_measured']=df['target_is_measured'].astype(str).str.lower().eq('true')
    return df

def chronological_split(df):
    """Split observations 70/15/15 and drop labels crossing split boundaries.

    Args:
        df (pandas.DataFrame): Chronologically sorted data with target_time.
    Returns:
        tuple: Train, validation and test DataFrames.
    """
    n=len(df); a=int(n*.70); b=int(n*.85)
    train=df.iloc[:a].copy(); val=df.iloc[a:b].copy(); test=df.iloc[b:].copy()
    train=train.loc[train['target_time']<val['collecteddate'].iloc[0]].copy()
    val=val.loc[val['target_time']<test['collecteddate'].iloc[0]].copy()
    if min(len(train),len(val),len(test))<2:raise ValueError('Insufficient observations after boundary exclusion')
    return train,val,test

def scores(y_true,y_pred):
    """Return MAE, RMSE and R2 for continuous headcount predictions.

    Args:
        y_true (array-like): Sensor or processed target headcounts.
        y_pred (array-like): Predicted continuous headcounts.
    Returns:
        dict: MAE and RMSE in occupants; dimensionless R2.
    """
    return {'MAE':float(mean_absolute_error(y_true,y_pred)),
            'RMSE':float(np.sqrt(mean_squared_error(y_true,y_pred))),
            'R2':float(r2_score(y_true,y_pred))}
