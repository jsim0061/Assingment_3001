# MMA3001 — 15-minute room occupancy prediction

**Individual project | Numerical Methods and Machine Learning (2026)**

## Project
Predict the number of people in one monitored room **15 minutes ahead** using occupancy-sensor data. The potential engineering application is occupancy-aware HVAC operation; **HVAC energy savings were not measured**.

## Inputs and output
- **Raw inputs:** `floorspaceid` (room ID), `collecteddate` (timestamp), `headcount` (people).
- **Model features:** current occupancy, occupancy 15 and 30 minutes earlier, hour, minute, and day of week.
- **Output:** predicted occupancy in 15 minutes (people; regression output can be fractional).
- **Preprocessing assumption:** retain the last headcount for up to 30 minutes without a new reading; longer gaps are treated as zero. These are *assumed*, not measured, values.

## Methods
- **Primary:** Decision Tree Regression, with validation-based depth selection.
- **Comparisons:** historical weekday/time-slot average, Linear Regression, and RBF Support Vector Regression.
- **Evaluation:** chronological 70% training / 15% validation / 15% test split; MAE, RMSE and R². Where available, report results on genuinely measured targets separately.

## Results
The written report gives the following **test results**; verify they match the final scripts and identical evaluation records before submission.

| Model | MAE (people) | RMSE (people) | R² |
|---|---:|---:|---:|
| Decision Tree | 0.286 | 0.578 | 0.452 |
| Historical Average | 0.448 | 0.705 | 0.185 |
| Linear Regression | 0.307 | 0.590 | 0.429 |
| SVR | 0.268 | 0.590 | 0.429 |

Decision Tree has the lowest reported RMSE and highest R²; SVR has the lowest MAE. These numbers are from the written report, not independently reproduced by this repository package.

## Runtime and memory benchmarking
Every model records **training/selection wall-clock time**, **test-set prediction wall-clock time**, **peak traced Python allocation** for each stage (MiB), and an estimated **serialized model size** (KiB; unavailable for the statistical historical average). Files are saved to `results/<model>_performance.csv`. The metrics are combined by `scripts/compare_results.py` into `results/model_comparison.csv`.

Run all four models on the **same computer, Python environment, and processed dataset** before comparing these figures. The SVR training time includes validation-based hyperparameter search and is fitted on at most 5,000 training rows, whereas the other fitted models use all training rows. The historical-average training time measures computing group means. **`tracemalloc` does not capture all native NumPy/scikit-learn RAM usage**, so its allocation peaks must not be presented as total RAM consumption. Times exclude CSV loading, plotting, and CSV output. No benchmark numbers have been fabricated; run the scripts locally to obtain them.

## Setup
Python 3.12 recommended. In the repository folder:

```bash
python -m pip install -r requirements.txt
```

Put the original occupancy ZIP **beside** `data_processing.py` with the expected name `5occupancySensor_MayToDec2024_9MRows.zip` (not included; only use if you have permission). Run:

```bash
python data_processing.py
python decision_tree.py
python scripts/historical_average.py
python scripts/linear_regression.py
python scripts/support_vector_regression.py
python scripts/compare_results.py
```

The preprocessing script writes `occupancy_15min_cleaned.csv` beside the Python files. The `scripts/` models use shared functions from `src/occupancy_prediction/core.py`.

## Tests and HTML documentation

```bash
python run_tests.py
python generate_docs.py
```

`run_tests.py` writes `results/test_report.txt` and `results/test_results.xml`. Open `docs/index.html` in a browser. Tests cover selected preprocessing and modelling behaviours; passing tests does **not** independently verify the experimental table above.

## Repository layout
- `data_processing.py`, `decision_tree.py`: original preprocessing and main model.
- `scripts/`: three alternative models and result comparison.
- `src/`, `occupancy_utils.py`: reusable functions.
- `tests/`: automated tests.
- `docs/`: HTML code documentation.
- `results/`: generated test reports and model outputs (created when scripts run).
- `AI_USE_LOG.md`: AI use and reflection (review for accuracy).
- `LICENSE`: source-code rights notice.

## Limitations
Only one room was used for the main modelling investigation. Missing sensor readings, the zero-after-30-minutes assumption and distribution changes may bias results. Decision trees do not extrapolate beyond the behaviour represented by their training samples. SVR uses a smaller training subset for computational reasons. The data must not be redistributed without appropriate permission.

## AI use
ChatGPT assisted with coding, debugging, project structure, documentation and report drafting. See `AI_USE_LOG.md`; the author must verify the final description of AI involvement and independently check the code and results.
