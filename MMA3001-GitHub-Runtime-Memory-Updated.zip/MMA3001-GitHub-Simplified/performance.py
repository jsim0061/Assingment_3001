"""Measure wall-clock duration and peak traced Python allocations.

Peak_Python_Memory_MiB measures Python-tracked allocations via tracemalloc,
NOT total process RAM, and may omit NumPy / scikit-learn native allocations.
Model_Size_KiB is a serialised-size estimate, not process memory.
"""
import pickle
import time
import tracemalloc


def profile_call(func, *args, **kwargs):
    """Run func once, returning (result, seconds, peak Python MiB).

    Tracing is started fresh for each section; avoid nested calls to this helper.
    """
    tracemalloc.start()
    tracemalloc.reset_peak()
    start = time.perf_counter()
    try:
        result = func(*args, **kwargs)
        elapsed = time.perf_counter() - start
        _, peak = tracemalloc.get_traced_memory()
    finally:
        tracemalloc.stop()
    return result, elapsed, peak / (1024 ** 2)


def model_size_kib(model):
    """Return estimated serialised model size in KiB (not its RAM usage)."""
    return len(pickle.dumps(model, protocol=pickle.HIGHEST_PROTOCOL)) / 1024


def save_profile(folder, name, *, training_s, prediction_s, train_peak_mib,
                 prediction_peak_mib, model_kib=None, n_train=None, n_test=None):
    """Write a one-row CSV documenting per-model profiling scope and units."""
    from pathlib import Path
    import pandas as pd
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    row = dict(Model=name, Training_Time_s=training_s,
               Test_Prediction_Time_s=prediction_s,
               Training_Peak_Python_MiB=train_peak_mib,
               Test_Prediction_Peak_Python_MiB=prediction_peak_mib,
               Model_Size_KiB=model_kib, Training_Rows=n_train, Test_Rows=n_test)
    pd.DataFrame([row]).to_csv(folder / f"{name}_performance.csv", index=False)
    print(f"PERFORMANCE {name}: training {training_s:.4f}s, test predict {prediction_s:.4f}s; "
          f"Python alloc peak train {train_peak_mib:.2f} MiB, "
          f"predict {prediction_peak_mib:.2f} MiB", flush=True)
    return row
