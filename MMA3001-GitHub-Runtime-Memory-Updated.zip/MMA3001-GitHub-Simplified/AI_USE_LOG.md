# AI use log — complete and verify before submission

| Task | AI assistance | How the output was checked | Decisions retained by student |
|---|---|---|---|
| Project planning | Assistance interpreting the brief and proposing occupancy prediction | [Add actual checks] | [Add actual decisions] |
| Python development | Drafting and debugging processing, regression, comparison and testing scripts | [List runs, errors, corrections] | [List model design decisions] |
| Documentation | Drafting README, module documentation and tests | [Confirm everything accurately reflects source code] | [Add edits and reasoning] |

Include your actual tools, approximate level of contribution, mistakes found and final reflection in the report. Do not submit unverified placeholders.
