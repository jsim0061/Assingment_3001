"""Unit checks of runtime / Python-allocation measurement helpers."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import pandas as pd
from performance import profile_call, model_size_kib, save_profile


def test_profile_call_returns_result_and_nonnegative_metrics():
    output, seconds, mib = profile_call(lambda: [0] * 1000)
    assert len(output) == 1000
    assert seconds >= 0
    assert mib >= 0


def test_model_size_is_positive():
    assert model_size_kib({"model": [1, 2]}) > 0


def test_save_profile_columns(tmp_path):
    save_profile(tmp_path, 'example', training_s=1, prediction_s=.2,
                 train_peak_mib=3, prediction_peak_mib=2, model_kib=0.5,
                 n_train=100, n_test=10)
    df = pd.read_csv(tmp_path/'example_performance.csv')
    assert df.loc[0, 'Training_Rows'] == 100
    assert df.loc[0, 'Test_Prediction_Time_s'] == .2
