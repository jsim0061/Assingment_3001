"""Tests for shareable project code; no Monash dataset required."""
import sys
from pathlib import Path
import numpy as np
import pandas as pd
import pytest
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from occupancy_prediction.core import FEATURES, TARGET, chronological_split, scores, load_data

def mock_data(n=100):
    times=pd.date_range('2024-06-01',periods=n,freq='15min',tz='UTC')
    data={name:np.zeros(n) for name in FEATURES}
    data.update({'collecteddate':times,'target_time':times+pd.Timedelta(minutes=15),TARGET:np.ones(n)})
    return pd.DataFrame(data)

def test_split_no_crossing_targets():
    train,val,test=chronological_split(mock_data())
    assert train.target_time.max()<val.collecteddate.min()
    assert val.target_time.max()<test.collecteddate.min()
    assert all(p.collecteddate.is_monotonic_increasing for p in (train,val,test))

def test_split_coverage():
    train,val,test=chronological_split(mock_data())
    assert all(len(x)>0 for x in (train,val,test))
    assert len(train)+len(val)+len(test)<=100

def test_scores_exact():
    result=scores([2,4,6],[2,4,6])
    assert result['MAE']==0 and result['RMSE']==0 and result['R2']==1

def test_scores_known_values():
    result=scores([2,4,6],[3,4,5])
    assert result['MAE']==pytest.approx(2/3)
    assert result['RMSE']==pytest.approx((2/3)**.5)

def test_load_missing_column(tmp_path):
    file=tmp_path/'bad.csv';pd.DataFrame({'collecteddate':['2024-01-01']}).to_csv(file,index=False)
    with pytest.raises(ValueError,match='Missing required columns'):load_data(file)

def test_load_sorts_records(tmp_path):
    original=mock_data(30).sample(frac=1,random_state=3)
    file=tmp_path/'good.csv';original.to_csv(file,index=False)
    loaded=load_data(file)
    assert loaded.collecteddate.is_monotonic_increasing
    assert len(loaded)==30
