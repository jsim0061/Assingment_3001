"""Shared command-line script helpers."""
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
sys.path.insert(0,str(ROOT))
from occupancy_prediction.core import FEATURES, TARGET, load_data, chronological_split, scores
import pandas as pd
from performance import profile_call, save_profile, model_size_kib

def save_evaluations(name, model, splits, predict, folder, training_profile=None, training_rows=None):
    """Save train/validation/test scores, measured-only test scores, and test predictions."""
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=True)
    rows=[]
    test_profile = None
    for label,part in zip(['Training','Validation','Testing'],splits):
        if label == 'Testing':
            prediction, predict_seconds, predict_peak = profile_call(predict, part)
            test_profile = (predict_seconds, predict_peak)
        else:
            prediction=predict(part)
        rows.append({'Dataset':label,**scores(part[TARGET],prediction)})
        if label=='Testing':
            output=pd.DataFrame({'target_time':part['target_time'].to_numpy(),
                   'actual_occupancy':part[TARGET].to_numpy(), 'predicted_occupancy':prediction})
            if 'target_is_measured' in part:
                output['target_is_measured']=part['target_is_measured'].to_numpy()
                mask=part['target_is_measured'].to_numpy(dtype=bool)
                if mask.sum()>=2:
                    rows.append({'Dataset':'Measured Targets Only',**scores(part[TARGET].to_numpy()[mask],prediction[mask])})
            output.to_csv(folder/f'{name}_predictions.csv',index=False)
    pd.DataFrame(rows).to_csv(folder/f'{name}_results.csv',index=False)
    print(pd.DataFrame(rows).to_string(index=False))

    if training_profile is not None and test_profile is not None:
        save_profile(folder, name, training_s=training_profile[0],
                     prediction_s=test_profile[0], train_peak_mib=training_profile[1],
                     prediction_peak_mib=test_profile[1],
                     model_kib=model_size_kib(model) if model is not None else None,
                     n_train=training_rows if training_rows is not None else len(splits[0]),
                     n_test=len(splits[2]))
